const reponse = await fetch("MENU_ELEMENTS.json");
const MENU_ELEMENTS = await reponse.json();

for (let i = 0; i < MENU_ELEMENTS.length; i+=2){
    const PARA_ELEMENT = document.createElement("p");
    PARA_ELEMENT.innerHTML = "<a href='"+MENU_ELEMENTS[i+1]+"'>"+MENU_ELEMENTS[i]+"</a>";

    const PARENT = document.querySelector(".menu");
    PARENT.appendChild(PARA_ELEMENT);
}