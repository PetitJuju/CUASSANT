const reponse = await fetch("TRANSAC_ELEMENTS.json");
const TRANSAC_ELEMENTS = await reponse.json();

for (let i = 0; i < TRANSAC_ELEMENTS.length; i++){
    /*Creating section element for each transaction*/
    const SEC_ELEMENT = document.createElement("section");
    SEC_ELEMENT.setAttribute("id", "SECTION"+i)
    SEC_ELEMENT.setAttribute("class", "transac-section")
    let PARENT = document.querySelector(".sections");
    PARENT.appendChild(SEC_ELEMENT);

    /*Creating partner for each transaction*/
    let PARA_ELEMENT_PARTNER = document.createElement("h1");
    PARA_ELEMENT_PARTNER.innerText = TRANSAC_ELEMENTS[i]["partenaire"];

    PARENT = document.querySelector("#SECTION"+i);
    PARENT.appendChild(PARA_ELEMENT_PARTNER);

    /*Creating Description for each transaction*/
    let PARA_ELEMENT_DESC = document.createElement("p");
    PARA_ELEMENT_DESC.innerText = "Description: "+TRANSAC_ELEMENTS[i]["desc"];

    PARENT = document.querySelector("#SECTION"+i);
    PARENT.appendChild(PARA_ELEMENT_DESC);

    /*Creating title for each transaction*/
    let PARA_ELEMENT_NO = document.createElement("p");
    PARA_ELEMENT_NO.innerText = "Transaction ID | "+TRANSAC_ELEMENTS[i]["no"];

    PARENT = document.querySelector("#SECTION"+i);
    PARENT.appendChild(PARA_ELEMENT_NO);

    /*Creating date for each transaction*/
    let PARA_ELEMENT_DATE = document.createElement("p");

    const dateToFormat = new Date(TRANSAC_ELEMENTS[i]["date-transac"]);

    if (isNaN(dateToFormat)) {
        console.error("Invalid date: "+dateToFormat);
        continue; // Skip this iteration and move to the next transaction
    }

    const dateToShow = new Intl.DateTimeFormat("en-US", {
        year: "numeric",
        month: "long",
        day: "numeric",
      }).format(dateToFormat);

    PARA_ELEMENT_DATE.innerText = "Date: "+dateToShow;

    PARENT = document.querySelector("#SECTION"+i);
    PARENT.appendChild(PARA_ELEMENT_DATE);

    /*Creating money for each transaction*/
    let PARA_ELEMENT_MONEY = document.createElement("p");

    const moneyToFormat = TRANSAC_ELEMENTS[i]["somme"];
    const moneyToShow= new Intl.NumberFormat("en-CA", {
        style: "currency",
        currency: "CAD",
      }).format(moneyToFormat);

    if (TRANSAC_ELEMENTS[i]["bilan"] == "positif"){
       PARA_ELEMENT_MONEY.setAttribute("class", "positive_money");
       PARA_ELEMENT_MONEY.innerText = "Somme: "+moneyToShow;
    }
    else{
        PARA_ELEMENT_MONEY.setAttribute("class", "negative_money");
        PARA_ELEMENT_MONEY.innerText = "Somme: -"+moneyToShow;
    }

    PARENT = document.querySelector("#SECTION"+i);
    PARENT.appendChild(PARA_ELEMENT_MONEY);


}